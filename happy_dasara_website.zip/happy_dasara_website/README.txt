ಶುಭ ದಸರಾ Website — Run locally

1. Extract the ZIP file.
2. Open the dasara_website folder.
3. Double-click index.html to open it in Chrome or Edge.
4. For editing, open index.html in VS Code.

The site is responsive and includes Kannada greetings, tradition cards, copy-to-clipboard,
native share, and WhatsApp sharing. Kannada web font loads from Google Fonts when online.
To publish it online, upload index.html to GitHub Pages, Netlify, or another static host.
